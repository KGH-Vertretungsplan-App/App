screen -S vertretungsplan while ( true ) do ./30.sh; sleep 1; done;

