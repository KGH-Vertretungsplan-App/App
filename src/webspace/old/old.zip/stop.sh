screen -r vertretungsplan -X quit
