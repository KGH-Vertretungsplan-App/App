# In diesem Skript wird bearbeitet, das die Datei vom Server genommen wird und auf dem Rootserver in Frankfurt gespeichert wird.
rm subst_001.htm
rm subst_002.htm
rm subst_003.htm
rm subst_004.htm
rm subst_005.htm
wget http://www.kreisgymnasium-halle.de/wp-content/uploads/Service/vertretungsplan/subst_001.htm
wget http://www.kreisgymnasium-halle.de/wp-content/uploads/Service/vertretungsplan/subst_002.htm
wget http://www.kreisgymnasium-halle.de/wp-content/uploads/Service/vertretungsplan/subst_003.htm
wget http://www.kreisgymnasium-halle.de/wp-content/uploads/Service/vertretungsplan/subst_004.htm
wget http://www.kreisgymnasium-halle.de/wp-content/uploads/Service/vertretungsplan/subst_005.htm
echo Der Skript wurde ausgeführt und es sind keine Fehler aufgetreten.
# Aufgabe erledigt.
